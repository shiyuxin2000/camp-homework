## Homework 3



+ Task 1

task 1效果(完成指定效果)

<img src="C:\Users\syx2000\AppData\Roaming\Typora\typora-user-images\image-20210714205815476.png" alt="image-20210714205815476" style="zoom:33%;" />

+ Task2

  task2效果(已经完成指定效果)

  <img src="C:\Users\syx2000\AppData\Roaming\Typora\typora-user-images\image-20210714205706191.png" alt="image-20210714205706191" style="zoom:33%;" />

+ Task 3

动画界面

<img src="C:\Users\syx2000\AppData\Roaming\Typora\typora-user-images\image-20210714205419601.png" alt="image-20210714205419601" style="zoom:33%;" />

5s后跳转到列表，使用recycleView实现的热搜榜(与homework2类似)

<img src="C:\Users\syx2000\AppData\Roaming\Typora\typora-user-images\image-20210714205527491.png" alt="image-20210714205527491" style="zoom: 33%;" />

