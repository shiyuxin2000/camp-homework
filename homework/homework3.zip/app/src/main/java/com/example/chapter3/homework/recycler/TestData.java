package com.example.chapter3.homework.recycler;


public class TestData {

    String title;
    String hot;

    public TestData(String title, String hot) {
        this.title = title;
        this.hot = hot;
    }
}
